Este es el plugin gestion de acceso cuyo objetivo es la administraci�n de los equipos Cliente.
Es un plugin gratuito, asi que no est� muy adaptado a cualquier usuario.
Tiene unos parametros que a nosotros nos resultan suficiente.
Primero tiene un listado dentro del cliente (gesti�n de acceso) para ver todas las m�quinas con los datos mas relevantes (COncepto, Descripci�n, Usuario, IP, Teamviewer).
Y dentro de cada ficha de Usuario:
 - Concepto (PC, Servidor, MV, ...)
 - Descripci�n
 - Usuario
 - IP del equipo
 - Teamviewer (para tener la ID)
 - Hardware
 - Password
 - Splashtop (otro programa de control remoto, para tener el nombre de equipo)
 - Notas. Para apuntar lo que necesites.